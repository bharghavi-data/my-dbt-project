-- models/data_vault/staging/sat_geo_combined.sql
{{ config(materialized='table') }}

with base_data as (

    select
        md5(coalesce(trim(cast(rli.GEO_ID as string)), '')) as GEO_HK,

        rli.GEO_ID as GEO_ID,
        {{ clean_column('rli.GEO_NAME', to_lower=true) }} as GEO_NAME,
        {{ clean_column('rli.ISO_3166_2_CODE', to_lower=true) }} as ISO_3166_2_CODE,
        {{ clean_column('rli.ISO_ALPHA2', to_lower=true) }} as ISO_ALPHA2,
        {{ clean_column('rli.ISO_ALPHA3', to_lower=true) }} as ISO_ALPHA3,
        {{ clean_column('rli.ISO_NAME', to_lower=true) }} as ISO_NAME,
        {{ clean_column('rli.ISO_NUMERIC_CODE', to_lower=true) }} as ISO_NUMERIC_CODE,
        {{ clean_column('rli.LEVEL', to_lower=true) }} as LEVEL,

        current_timestamp() as LOAD_DATE,
        'JOINED_GEO_REL' as RECORD_SOURCE,

        -- alias for macro expectations
        {{ clean_column('rli.GEO_NAME', to_lower=true) }} as name,  
        current_timestamp() as last_updated                         
    from {{ ref('raw_location_index') }} rli
    inner join {{ ref('raw_geo_relationships') }} gr
        on rli.GEO_ID = gr.GEO_ID
    where rli.GEO_ID is not null
)

select *
from {{ remove_duplicates(
    relation='base_data',
    key_columns=['GEO_HK']
) }}














/*{{ config(materialized='table') }}

select
    md5(coalesce(trim(cast(rli.GEO_ID as string)), '')) as GEO_HK,

    {{ clean_column('rli.GEO_ID', to_lower=true, remove_special_chars=true) }} as GEO_ID,
    {{ clean_column('rli.GEO_NAME', to_lower=true) }} as GEO_NAME,
    {{ clean_column('rli.ISO_3166_2_CODE', to_lower=true) }} as ISO_3166_2_CODE,
    {{ clean_column('rli.ISO_ALPHA2', to_lower=true) }} as ISO_ALPHA2,
    {{ clean_column('rli.ISO_ALPHA3', to_lower=true) }} as ISO_ALPHA3,
    {{ clean_column('rli.ISO_NAME', to_lower=true) }} as ISO_NAME,
    {{ clean_column('rli.ISO_NUMERIC_CODE', to_lower=true) }} as ISO_NUMERIC_CODE,
    {{ clean_column('rli.LEVEL', to_lower=true) }} as LEVEL,

    current_timestamp() as LOAD_DATE,
    'JOINED_GEO_REL' as RECORD_SOURCE

from {{ ref('raw_location_index') }} rli
inner join {{ ref('raw_geo_relationships') }} gr
    on rli.GEO_ID = gr.GEO_ID
where rli.GEO_ID is not null
*/