{{ config(
    materialized='incremental',
    unique_key='geo_hk'
) }}

{% set tracked_fields = [
    'geo_id', 'geo_name', 'iso_3166_2_code',
    'iso_alpha2', 'iso_alpha3', 'iso_name',
    'iso_numeric_code', 'level', 'record_source'
] %}

{{ scd2_merge_auto(
    target = this,
    source = ref('stg_geo_combined'),
    unique_key = 'geo_hk',
    tracked_fields = tracked_fields
) }}


/*{{ config(materialized='table') }}

{% set tracked_fields = [
    'geo_id', 'geo_name', 'iso_3166_2_code',
    'iso_alpha2', 'iso_alpha3', 'iso_name',
    'iso_numeric_code', 'level', 'record_source'
] %}

{{ scd2_merge_auto(
    target = this,
    source = ref('stg_geo_combined'),
    unique_key = 'geo_hk',
    tracked_fields = tracked_fields
) }} */
