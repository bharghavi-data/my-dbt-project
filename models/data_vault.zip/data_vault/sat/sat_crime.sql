
{{ config(
    materialized='incremental',
    unique_key='crime_hk'
) }}

{% set tracked_fields = [
    'variable', 
    'variable_name', 
    'offense_category', 
    'measure',
    'frequency', 
    'unit', 
    'observation_date', 
    'observation_value',
    'geo_id',  
    'record_source'
] %}

{{ scd2_merge_auto(
    target=this,
    source=ref('stg_crime_combined'),
    unique_key='crime_hk',
    tracked_fields=tracked_fields
) }}

/*{{ config(materialized='table') }}

{% set tracked_fields = [
    'variable', 'variable_name', 'offense_category', 'measure',
    'frequency', 'unit', 'observation_date', 'observation_value',
    'geo_id', 'load_date', 'record_source'
] %}

{{ scd2_merge_auto(
    target = this,
    source = ref('stg_crime_combined'),
    unique_key = 'crime_hk',
    tracked_fields = tracked_fields
) }} */


