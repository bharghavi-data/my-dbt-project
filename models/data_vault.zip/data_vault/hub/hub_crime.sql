{{ config(
    materialized='incremental',
    unique_key='crime_hk'
) }}

select distinct
    crime_hk,
    current_timestamp() as load_date,
    'HUB_CRIME' as record_source
from {{ ref('stg_crime_combined') }}
where crime_hk is not null

{% if is_incremental() %}
    and crime_hk not in (select crime_hk from {{ this }})
{% endif %}



/*{{ config(materialized='table') }}

select distinct
    CRIME_HK,
    current_timestamp() as LOAD_DATE,
    'HUB_CRIME' as RECORD_SOURCE
from {{ ref('stg_crime_combined') }}
where CRIME_HK is not null */
