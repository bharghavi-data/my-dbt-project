{{ config(materialized = 'table') }}

select *
from {{ source('cybersyn', 'GEOGRAPHY_INDEX') }}
where GEO_ID is not null
