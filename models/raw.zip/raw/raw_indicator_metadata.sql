{{ config(materialized = 'table') }}

select *
from {{ source('cybersyn', 'FBI_CRIME_ATTRIBUTES') }}
where VARIABLE is not null
