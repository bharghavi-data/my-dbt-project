{{ config(materialized = 'table') }}

select *
from {{ source('cybersyn', 'FBI_CRIME_TIMESERIES') }}
where VARIABLE is not null and GEO_ID is not null
